/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.oficina.dal;

import java.sql.*;

public class ModuloConexao {

    //metodo responsavel por estabelecer a conexao com banco
    public static Connection conector() {
        java.sql.Connection conexao = null;
        //chamada driver
        String driver = "com.mysql.jdbc.Driver";
        //Armazenando informaçoes referente ao banco
        String url = "jdbc:mysql://localhost:3306/dboficina";
        String user = "root";
        String password = "";
        //estabelecendo conexao
        try {
            Class.forName(driver);
            conexao = DriverManager.getConnection(url, user, password);
            return conexao;
        } catch (Exception e) {
            //System.out.println(e); 
            return null;
        }
    }
}
